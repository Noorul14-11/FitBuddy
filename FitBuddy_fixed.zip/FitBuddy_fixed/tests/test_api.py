from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get('/api/health')
    assert r.status_code == 200
    assert r.json()['status'] == 'ok'

def test_home():
    r = client.get('/')
    assert r.status_code == 200
    assert 'FitBuddy' in r.text

def test_generate_and_feedback():
    payload={"name":"Test User","age":25,"weight":70,"goal":"weight loss","intensity":"medium","experience":"beginner","equipment":"home"}
    r=client.post('/api/plans/generate',json=payload)
    assert r.status_code==200
    data=r.json(); assert len(data['content']['days'])==7
    f=client.post(f"/api/plans/{data['id']}/feedback",json={"feedback":"Add more cardio and one rest day."})
    assert f.status_code==200
    assert len(f.json()['content']['days'])==7

def test_tip():
    r=client.post('/api/tips',json={"goal":"muscle gain"})
    assert r.status_code==200
    assert r.json()['tip']
