from typing import Any, Literal
from pydantic import BaseModel, Field, ConfigDict

Goal = Literal["weight loss", "muscle gain", "general wellness"]
Intensity = Literal["low", "medium", "high"]

class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    age: int = Field(ge=13, le=100)
    weight: float = Field(gt=20, lt=400)
    goal: Goal
    intensity: Intensity
    experience: str = Field(default="beginner", min_length=2, max_length=30)
    equipment: str = Field(default="home", min_length=2, max_length=100)

class UserOut(UserCreate):
    id: int
    model_config = ConfigDict(from_attributes=True)

class PlanGenerate(UserCreate):
    feedback: str | None = Field(default=None, max_length=2000)

class FeedbackIn(BaseModel):
    feedback: str = Field(min_length=3, max_length=2000)

class TipRequest(BaseModel):
    goal: Goal

class PlanOut(BaseModel):
    id: int
    user_id: int
    content: dict[str, Any]
    feedback: str | None
    created_at: str
