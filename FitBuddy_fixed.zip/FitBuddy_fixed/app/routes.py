import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .database import get_db
from .models import User, Plan
from .schemas import UserCreate, UserOut, PlanGenerate, FeedbackIn, TipRequest
from .ai_service import AIService

router = APIRouter(prefix="/api")
ai = AIService()

def plan_out(plan: Plan):
    return {"id": plan.id, "user_id": plan.user_id, "content": json.loads(plan.content), "feedback": plan.feedback, "created_at": plan.created_at.isoformat()}


@router.post("/users", response_model=UserOut, status_code=201)
def create_user(payload: UserCreate, db: Session = Depends(get_db)):
    user = User(**payload.model_dump()); db.add(user); db.commit(); db.refresh(user); return user

@router.get("/users/{user_id}", response_model=UserOut)
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user: raise HTTPException(404, "User not found")
    return user

@router.post("/plans/generate")
def generate_plan(payload: PlanGenerate, db: Session = Depends(get_db)):
    data = payload.model_dump(); feedback = data.pop("feedback", None)
    user = User(**data); db.add(user); db.flush()
    content = ai.generate_plan(data, feedback)
    plan = Plan(user_id=user.id, content=json.dumps(content), feedback=feedback)
    db.add(plan); db.commit(); db.refresh(plan)
    return plan_out(plan)

@router.post("/plans/{plan_id}/feedback")
def regenerate_plan(plan_id: int, payload: FeedbackIn, db: Session = Depends(get_db)):
    old = db.get(Plan, plan_id)
    if not old: raise HTTPException(404, "Plan not found")
    user = db.get(User, old.user_id)
    profile = {"name": user.name, "age": user.age, "weight": user.weight, "goal": user.goal, "intensity": user.intensity, "experience": user.experience, "equipment": user.equipment}
    content = ai.generate_plan(profile, payload.feedback)
    plan = Plan(user_id=user.id, content=json.dumps(content), feedback=payload.feedback)
    db.add(plan); db.commit(); db.refresh(plan)
    return plan_out(plan)

@router.get("/plans/{plan_id}")
def get_plan(plan_id: int, db: Session = Depends(get_db)):
    plan = db.get(Plan, plan_id)
    if not plan: raise HTTPException(404, "Plan not found")
    return plan_out(plan)

@router.get("/users/{user_id}/plans")
def user_plans(user_id: int, db: Session = Depends(get_db)):
    if not db.get(User, user_id): raise HTTPException(404, "User not found")
    return [plan_out(p) for p in db.query(Plan).filter(Plan.user_id == user_id).order_by(Plan.id.desc()).all()]

@router.post("/tips")
def nutrition_tip(payload: TipRequest):
    return ai.generate_tip(payload.goal)
