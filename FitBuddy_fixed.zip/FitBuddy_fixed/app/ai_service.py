import json
from typing import Any
from .config import settings

GOAL_FOCUS = {
    "weight loss": "moderate calorie expenditure, cardio, full-body resistance training, and recovery",
    "muscle gain": "progressive resistance training, adequate protein, and recovery",
    "general wellness": "balanced strength, mobility, light cardio, and sustainable recovery",
}

class AIService:
    def __init__(self):
        self.client = None
        if settings.gemini_api_key:
            try:
                from google import genai
                self.client = genai.Client(api_key=settings.gemini_api_key)
            except Exception:
                self.client = None

    def generate_plan(self, profile: dict[str, Any], feedback: str | None = None) -> dict[str, Any]:
        if self.client:
            try:
                return self._gemini_plan(profile, feedback)
            except Exception:
                pass
        return self._fallback_plan(profile, feedback)

    def generate_tip(self, goal: str) -> dict[str, str]:
        if self.client:
            prompt = f"Give one concise, practical nutrition or recovery tip for a fitness user whose goal is {goal}. Return JSON with keys tip and rationale. No medical claims."
            try:
                data = self._json_response(prompt)
                if data.get("tip"):
                    return {"tip": str(data["tip"]), "rationale": str(data.get("rationale", ""))}
            except Exception:
                pass
        tips = {
            "weight loss": ("Build meals around vegetables, a protein source, and minimally processed carbohydrates.", "This supports satiety and steady training energy without requiring extreme restriction."),
            "muscle gain": ("Include a protein-rich meal or snack after training and spread protein across the day.", "Consistent protein intake supports muscle repair alongside progressive training."),
            "general wellness": ("Hydrate regularly and aim for a consistent sleep routine.", "Recovery habits help support energy, performance, and long-term exercise consistency."),
        }
        tip, rationale = tips[goal]
        return {"tip": tip, "rationale": rationale}

    def _gemini_plan(self, p, feedback):
        prompt = f"""You are FitBuddy, a conservative fitness-planning assistant. Create a practical 7-day plan for this user: {json.dumps(p)}. Goal focus: {GOAL_FOCUS[p['goal']]}. Feedback: {feedback or 'none'}. Return ONLY valid JSON with this shape: {{\"summary\": string, \"days\": [{{\"day\": 1, \"title\": string, \"workout\": [string], \"duration_minutes\": number, \"recovery\": string}} x7], \"nutrition_tip\": string, \"safety\": string}}. Avoid diagnosis, extreme diets, or unsafe exercise. Include at least one easier recovery day."""
        return self._json_response(prompt)

    def _json_response(self, prompt):
        response = self.client.models.generate_content(model=settings.gemini_model, contents=prompt)
        text = response.text.strip()
        if text.startswith("```"):
            text = text.strip("`").replace("json\n", "", 1).strip()
        data = json.loads(text)
        if not isinstance(data.get("days"), list) or len(data["days"]) != 7:
            raise ValueError("Invalid 7-day response")
        return data

    def _fallback_plan(self, p, feedback=None):
        goal = p["goal"]; intensity = p["intensity"]; exp = p["experience"]
        rest = "20–30 min easy walk + mobility" if intensity != "high" else "25–35 min easy walk + mobility"
        cardio = "25–35 min brisk walking/cycling" if goal == "weight loss" else "15–25 min easy cardio"
        strength = ["Squats or chair squats: 3×8–12", "Push-ups (wall/knee/full): 3×6–12", "Rows with band/backpack: 3×8–12", "Glute bridges: 3×10–15", "Plank: 3×20–40 sec"]
        if goal == "muscle gain": strength += ["Split squats: 3×8–12/side", "Overhead press with safe load: 3×8–12"]
        days = [
            ("Full-body strength", strength, 40),
            ("Cardio + mobility", [cardio, "10 min full-body mobility"], 40),
            ("Lower-body strength", ["Squats: 3×8–12", "Reverse lunges: 3×8–10/side", "Glute bridges: 3×12", "Calf raises: 3×12–15"], 35),
            ("Recovery day", [rest], 30),
            ("Upper-body strength", ["Push-ups: 3×6–12", "Rows: 3×8–12", "Shoulder press: 3×8–12", "Dead bug: 3×8/side"], 35),
            ("Cardio + core", [cardio, "Dead bug: 3×8/side", "Side plank: 3×20–30 sec/side"], 40),
            ("Active recovery", [rest, "Optional gentle stretching"], 30),
        ]
        if feedback:
            days[3] = ("Extra recovery", ["Easy walk 15–25 min", "Gentle mobility 10 min", f"Adjustment requested: {feedback[:120]}"], 30)
        return {"summary": f"A {intensity}-intensity beginner-friendly plan for {goal}, adapted for {exp} experience and {p['equipment']} equipment.",
                "days": [{"day": i+1, "title": t, "workout": w, "duration_minutes": d, "recovery": "Stop if you feel pain, dizziness, chest pain, or unusual symptoms."} for i,(t,w,d) in enumerate(days)],
                "nutrition_tip": self.generate_tip(goal)["tip"],
                "safety": "General fitness guidance only. Use safe technique and consult a qualified professional for individual medical or injury-related advice."}
