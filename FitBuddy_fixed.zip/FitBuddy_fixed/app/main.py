from pathlib import Path
import logging
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from .config import settings, PROJECT_ROOT, DATA_DIR
from .database import Base, engine
from . import models
from .routes import router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("fitbuddy")

BASE = Path(__file__).resolve().parent
DATA_DIR.mkdir(parents=True, exist_ok=True)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.app_name,
    version="1.1.0",
    description="AI-powered personalized fitness planner",
)
app.include_router(router)
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE / "templates"))

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={},
    )

@app.get("/api/health")
async def health_check():
    return {"status": "ok", "service": settings.app_name}

@app.exception_handler(Exception)
async def unhandled_exception(request: Request, exc: Exception):
    logger.exception("Unhandled application error on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "FitBuddy encountered an internal error.",
            "error_type": type(exc).__name__,
            "hint": "Check the VS Code terminal for the full traceback.",
        },
    )
