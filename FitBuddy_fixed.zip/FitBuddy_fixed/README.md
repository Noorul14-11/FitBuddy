# FitBuddy — AI Fitness Planner

FitBuddy is a complete FastAPI web application that creates personalized 7-day workout plans and nutrition/recovery tips using Google's Gemini models. It stores users, plans, and feedback in SQLite.

## Features
- Responsive HTML/CSS/JavaScript interface
- FastAPI REST API with OpenAPI docs
- Gemini AI integration using the modern `google-genai` SDK
- Safe deterministic fallback when `GEMINI_API_KEY` is not configured or Gemini is unavailable
- SQLite + SQLAlchemy persistence
- 7-day plans for weight loss, muscle gain, or general wellness
- Feedback-driven plan regeneration
- Nutrition/recovery tip endpoint
- Automated API tests
- VS Code launch/settings files

## Project structure
```text
FitBuddy/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── ai_service.py
│   ├── routes.py
│   ├── templates/index.html
│   └── static/{styles.css,app.js}
├── tests/test_api.py
├── data/.gitkeep
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## VS Code setup (Windows)
1. Install Python 3.10+ and Git.
2. Open this folder in VS Code.
3. Create a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
4. Install packages:
   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
5. Copy `.env.example` to `.env`.
6. For Gemini generation, put your Google AI API key in `GEMINI_API_KEY`. The app still works without it by using its local fallback planner.
7. Start the app:
   ```powershell
   uvicorn app.main:app --reload
   ```
8. Open http://127.0.0.1:8000
9. API documentation: http://127.0.0.1:8000/docs

## macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

## Testing
With the virtual environment activated:
```bash
pytest -q
```

## API endpoints
- `GET /api/health`
- `POST /api/users`
- `GET /api/users/{user_id}`
- `POST /api/plans/generate`
- `POST /api/plans/{plan_id}/feedback`
- `GET /api/plans/{plan_id}`
- `GET /api/users/{user_id}/plans`
- `POST /api/tips`

### Generate a plan example
```json
{
  "name": "Alex",
  "age": 28,
  "weight": 72,
  "goal": "weight loss",
  "intensity": "medium",
  "experience": "beginner",
  "equipment": "home"
}
```

### Feedback example
```json
{
  "feedback": "Please include more cardio and one additional rest day."
}
```

## Safety note
FitBuddy provides general fitness guidance, not medical advice. The UI asks users to stop if they experience pain, dizziness, chest pain, or unusual symptoms and to consult a qualified professional when appropriate.
