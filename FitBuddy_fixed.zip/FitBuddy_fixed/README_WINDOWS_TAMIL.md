# FitBuddy - Windows Quick Start (Tamil)

1. Open this folder in VS Code.
2. Open Terminal.
3. Run `python --version`.
4. Run `python -m venv .venv` if `.venv` does not exist.
5. Run `.venv\Scripts\python.exe -m pip install -r requirements.txt`.
6. Copy `.env.example` to `.env` and add `GEMINI_API_KEY` if available.
7. Start: `.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload`.
8. Open `http://127.0.0.1:8000`.
9. Health check: `http://127.0.0.1:8000/api/health`.
10. API docs: `http://127.0.0.1:8000/docs`.

PowerShell activation is NOT required.
If the browser shows an error, the terminal now logs the complete traceback and `/api/health` can be used to verify the backend.
